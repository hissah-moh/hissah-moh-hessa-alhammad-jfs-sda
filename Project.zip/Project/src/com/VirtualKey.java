package com;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;
import java.util.stream.*;


public class VirtualKey {
	
	
	 public static void main (String[]args) {
		 
		 System.out.println("----------------------------------------------------------------");
		 System.out.println("Welcome to my App , I hope it's helpful to you ");
		 System.out.println("----------------------------------------------------------------");
		 
		 VirtualKey V1 = new VirtualKey();
		  V1.Menu1();

		 
		 Scanner num = new Scanner(System.in);
	      int x = num.nextInt();
	      
	      
	      
		 try {
			switch (x) {
			
			  case 1:
				  
				  try {
						Files.list(Paths.get("C:\\Users\\h-alh\\Desktop\\SDA-JAVA Dev\\Phese 1\\PROJECT 1\\files")).forEach(System.out::println);
					} catch (IOException e) {

						e.printStackTrace();
					}
					System.out.println("All the files is in Ascending order");

			    break;
			    
			  case 2:
				  Menu2(); // calling from the method 
			    break;
			    
			  case 3:
			    System.out.println("Thank you for using my App.. ");
			    break;
			    }
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		 }
	 
	 
	 public static void Menu1() {
		 
		 System.out.println("----------------------------------------------------------------");
		 System.out.println("First of all you have to Choose what you want from the menu :  ");
		 System.out.println("1 - List files");
		 System.out.println("2 - The operations "); 
		 System.out.println("3 - Exit");
		 System.out.println("----------------------------------------------------------------");
		 
		 
		 
	 }
	
	 
	 


	public static void Menu2() throws IOException{
		
		 Scanner num = new Scanner(System.in);
		
		System.out.println("----------------------------------------------------------------");
		System.out.println("1 - Add files. ");
		System.out.println("2 - Delete files. ");
		System.out.println("3 - Search. ");
		System.out.println("4 - Back.  ");
		System.out.println("----------------------------------------------------------------");
		System.out.println("Enter your choise :");
		
		 
	      int choose = num.nextInt();
		 
			 
			 switch (choose) {
				
			  case 1:
				  
				  Scanner path4 = new Scanner(System.in);
					System.out.println("Enter your file name:");
				      String AFname = path4.nextLine();
				  
				  Path path = Paths.get("C:\\Users\\h-alh\\Desktop\\SDA-JAVA Dev\\Phese 1\\PROJECT 1\\files"+AFname);
					try {
						Path P = Files.createFile(path);
					} catch (IOException e) {

						e.printStackTrace();
					}
					System.out.println("the new file is added ");
					
				  
			    break;
			    
			  case 2:
				  
				  Scanner path5 = new Scanner(System.in);
					System.out.println("Enter your file name:");
				      String DFname = path5.nextLine();
			  
				  try {
						Files.deleteIfExists(Paths.get("C:\\Users\\h-alh\\Desktop\\SDA-JAVA Dev\\Phese 1\\PROJECT 1\\files"+DFname));
						System.out.println("the file is removed ! ");
					} catch (IOException e) {

						e.printStackTrace();
					}
				  
				
				  break;
				  
			  case 3:
				  Scanner path3 = new Scanner(System.in);
					System.out.println("Enter your file name:");
				      String Fname = path3.nextLine();
				  
				  Path path1 = Paths.get("C:\\Users\\h-alh\\Desktop\\SDA-JAVA Dev\\Phese 1\\PROJECT 1\\files");
			        List<Path> result = findByFileName(path1, Fname);
			        result.forEach(x -> System.out.println(x));
		
			        
				
			
			    break;
			    
			  case 4:
				  
				  VirtualKey V1 = new VirtualKey();
				  V1.Menu1();
				  
				  break;
			    default:
			    	
			    	System.out.println("Sorry , your choise is not available ..  ");	
			    }
			 	 
	 }

	 public static List<Path> findByFileName(Path path, String fileName)
	            throws IOException {

	        List<Path> result;
	        try (Stream<Path> pathStream = Files.find(path,
	                Integer.MAX_VALUE,
	                (p, basicFileAttributes) ->
	                        p.getFileName().toString().equalsIgnoreCase(fileName))
	        ) {
	            result = pathStream.collect(Collectors.toList());
	        }
	        return result;

	    }

	}

	  

