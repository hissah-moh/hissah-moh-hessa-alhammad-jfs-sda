package com;

import java.util.Scanner;

public class Calculator {


	  public static void main(String[] args) {

	    int operator;
	    int num1;
	    int num2;
	    int sum;

	    Scanner input = new Scanner(System.in);

	   
	    System.out.println("-------------------------------");
	    System.out.println("1 - Addition (+):");
	    System.out.println("2 - Subtraction (-):");
	    System.out.println("3 - Multiplication (*):");
	    System.out.println("4 - Division (/):");
	    System.out.println("-------------------------------");
	    
	    System.out.println("Choose your operator:");
	    operator = input.nextInt();


	    System.out.println("Enter your first number");
	    num1 = input.nextInt();

	    System.out.println("Enter your second number");
	    num2 = input.nextInt();

	    
	    switch (operator) {

	      case 1:
	        sum = num1 + num2;
	        System.out.println(num1 + " + " + num2 + " = " + sum);
	        break;

	   
	      case 2:
	    	  sum = num1 - num2;
	        System.out.println(num1 + " - " + num2 + " = " + sum);
	        break;

	     
	      case 3:
	    	  sum = num1 * num2;
	        System.out.println(num1 + " * " + num2 + " = " + sum);
	        break;

	     
	      case 4:
	    	  sum = num1 / num2;
	        System.out.println(num1 + " / " + num2 + " = " + sum);
	        break;

	      default:
	        System.out.println("Invalid operator!");
	        break;
	    }


	  }
	}


