package com;

import java.io.FileWriter; 
import java.io.IOException; 
import java.io.File; 
import java.io.FileNotFoundException; 
import java.util.Scanner; 
 

public class ReadAndWrite {

	public static void main(String[]args) { 
		
		 String text = "hello everyone , This is a java FSD course "; 
		 
		try {
	
			FileWriter myWriter = new FileWriter("hessa.txt");
			 
			myWriter.write(text); 
			myWriter.flush();
			myWriter.close(); 
			
			System.out.println("Successfully wrote to the file.");
			}
		
		catch (Exception e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
			
			}
		
			
	try {
		
		File f1 = new File("hessa.txt");  
		
		Scanner myReader = new Scanner(f1);
		
		while (myReader.hasNextLine()) {
			
		String data = myReader.nextLine();
		System.out.println(data);
		
		}
		myReader.close();
		}
	catch (FileNotFoundException e) {
		System.out.println("An error occurred.");
		e.printStackTrace();
		
		}
		}
	}
	
	
	